package com.act.demo.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class IncentiveResult {
    private String empId;
    private String employeeName;
    private Long amount;
}
