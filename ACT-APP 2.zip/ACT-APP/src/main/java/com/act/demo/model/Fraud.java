package com.act.demo.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Fraud {
    private String empId;
}
